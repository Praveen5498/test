package com.player.profile.PlayerController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.player.profile.PlayerBean.Players;
import com.player.profile.Service.PlayerService;
import com.player.profile.Service.PlayerServiceInterface;

@RestController
@RequestMapping("/info")
public class PlayerController  {

	private PlayerServiceInterface playerService;
	@Autowired
	public PlayerController(PlayerService ps) {
		this.playerService=ps;
	}
	@GetMapping("/players")
	public List<Players> getAllPlayers() {
		// TODO Auto-generated method stub
		
		return playerService.getAllPlayers();
	}

	@GetMapping("/players/{id}")	
	public Players getPlayer(@PathVariable int id) {
		// TODO Auto-generated method stub
		Players player = playerService.getPlayer(id);

		if (player == null) {
			throw new RuntimeException("Employee id not found - " + id);
		}
		return player;
	}

	@PostMapping("/players")
	public Players addPlayer(@RequestBody Players player) {
		// TODO Auto-generated method stub
		player.setId(0);

		playerService.addPlayer(player);

		return player;
	}
	@PutMapping("/players")
	public Players updatePlayer(@RequestBody Players player) {
		
		playerService.addPlayer(player);
		
		return player;
	}

	@DeleteMapping("/players/{id}")
	public String deletePlayer(@PathVariable int id) {
		// TODO Auto-generated method stub
		Players player = playerService.getPlayer(id);

		// throw exception if null

		if (player == null) {
			throw new RuntimeException("Employee id not found - " + id);
		}

		playerService.deleteById(id);

		return "Deleted employee id - " + id;

	}

}
